<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\SoldadosController;
use App\Http\Controllers\EquiposController;
use App\Http\Controllers\MisionesController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('soldado')->group(function(){

	Route::post('/crear',[SoldadosController::class, 'crearSoldado']);
	Route::post('/estado/{placa}',[SoldadosController::class, 'estadoSoldado']);
	Route::get('/listaTodos',[SoldadosController::class, 'listaTodos']);
	Route::get('/infoSoldado/{placa}',[SoldadosController::class, 'infoSoldado']);		
});

Route::prefix('equipo')->group(function(){

	Route::post('/crear',[EquiposController::class, 'crearEquipo']);
	Route::post('/modificar/{id}',[EquiposController::class, 'cambiarNombre']);
	Route::post('/borrar/{id}',[EquiposController::class, 'borrarEquipo']);
	Route::post('/asignar/{placa}',[EquiposController::class, 'asignarSoldado']);
	Route::post('/asignarCapitan/{placa}',[EquiposController::class, 'asignarCapitan']);
});

Route::prefix('mision')->group(function(){

	Route::post('/crear',[MisionesController::class, 'crearMision']);
	Route::post('/modificar/{codigo}',[MisionesController::class, 'modificarMision']);
	Route::get('/lista',[MisionesController::class, 'listaMisiones']);
	Route::post('/asignar/{id}',[MisionesController::class, 'asignarEquipo']);
	Route::post('/asignarSoldado/{placa}',[MisionesController::class, 'asignarSoldado']);
});
