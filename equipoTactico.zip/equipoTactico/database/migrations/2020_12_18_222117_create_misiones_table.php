<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMisionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('misiones', function (Blueprint $table) {
            $table->string('codigo', 20);
            $table->string('descripcion');
            $table->enum('prioridad',['normal', 'urgente', 'critica']);
            $table->date('fecha_registro');
            $table->enum('estado',['pendiente', 'en_curso', 'completa', 'fallida'])->default('pendiente');

            $table->integer('soldado_placa')->nullable();

            //$table->unsignedBigInteger('codigo_id')->nullable()->unique();

            $table->primary('codigo');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('misiones');
    }
}
