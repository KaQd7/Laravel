<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Relations extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('soldados', function(Blueprint $table)
        {
            $table->foreignId('equipo_id')->nullable()->constrained('equipos');

            $table->foreignId('capitan_id')->nullable()->constrained('equipos');
            $table->unique('capitan_id');
        });


        Schema::table('misiones', function(Blueprint $table)
        {
            $table->foreignId('codigo_id')->nullable()->constrained('equipos','equipo_codigo');
            $table->unique('codigo_id');

            $table->foreign('soldado_placa')->nullable()->references('placa')->on('soldados');
            
        });

        Schema::table('equipos', function(Blueprint $table)
        {
            $table->foreignId('soldado_id')->nullable()->constrained('soldados','capitan_id');
            $table->unique('soldado_id');

            //$table->foreignId('placa_id')->nullable()->constrained('soldados','placa');
            //$table->unique('placa_id');

            
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('soldados', function(Blueprint $table)
        {
            $table->dropForeign(['equipo_id']);
            $table->dropColumn('equipo_id');

            $table->dropForeign(['capitan_id']);
            $table->dropColumn('capitan_id');
        });

        Schema::table('equipos', function(Blueprint $table)
        {
            $table->dropForeign(['soldado_id']);
            $table->dropColumn('soldado_id');

            $table->dropForeign(['equipo_codigo']);
            $table->dropColumn('equipo_codigo');

        });

        Schema::table('misiones', function(Blueprint $table)
        {
            $table->dropForeign(['codigo_id']);
            $table->dropColumn('codigo_id');

        });
    }
}
