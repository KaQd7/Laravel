<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Registros extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registros', function (Blueprint $table) {
            $table->id();
            $table->string('codigo', 20);
            $table->string('descripcion');
            $table->enum('prioridad',['normal', 'urgente', 'critica']);
            $table->date('fecha_registro');
            $table->enum('estado',['pendiente', 'en_curso', 'completa', 'fallida'])->default('pendiente');

            $table->integer('soldado_placa')->nullable();

            $table->foreign('codigo')->nullable()->references('codigo')->on('misiones');

            //$table->unsignedBigInteger('codigo_id')->nullable()->unique();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
