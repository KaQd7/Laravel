<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\equipo;
use App\Models\soldado;

class EquiposController extends Controller
{
    public function crearEquipo(Request $request){

    	$respuesta = "";

    	$data = $request->getContent();

    	$data = json_decode($data);



    	$equipo = new equipo();

        //echo $equipo->id;

    	$equipo->nombre = $data->nombre;

    	try{
    		$equipo->save();
            $equipo->equipo_codigo = $equipo->id;
            $equipo->save();
    		$respuesta = "Equipo guardado en la base de datos";
    	}catch(\Exception $e){
    		$respuesta = $e->getMessage();
    	}


    	return response($respuesta);
    }

    public function cambiarNombre(Request $request, $id){
    	$respuesta = "";

    	$equipo = equipo::find($id);

    	//var_dump($equipo);

    	if (!is_null($equipo)) {
    		$data = $request->getContent();

    		$data = json_decode($data);

    		$equipo->nombre = (isset($data->nombre) ? $data->nombre : $equipo->nombre);
    		try{
	    		$equipo->save();
	    		$respuesta = "El nombre del equipo se ha cambiado correctamente";
	    	}catch(\Exception $e){
	    		$respuesta = $e->getMessage();
	    	}
    	}else{
    		$respuesta = "El equipo no existe";
    	}

    	return response($respuesta);
    	
    }

    public function borrarEquipo(Request $request, $id){
    	$respuesta = "";

    	$equipo = equipo::find($id);

    	//var_dump($equipo);

    	if (!is_null($equipo)) {
    		try{
	    		$equipo->delete();
	    		$respuesta = "El equipo se ha eliminado correctamente";
	    	}catch(\Exception $e){
	    		$respuesta = $e->getMessage();
	    	}
    	}else{
    		$respuesta = "El equipo no existe";
    	}

    	return response($respuesta);
    	
    }

    public function asignarSoldado(Request $request, $placa){
    	$respuesta = "";

    	$soldado = soldado::find($placa);

    	//$infoSoldado = DB::table('soldados')->whereIn('id', array(...))->get();

    	//var_dump($soldado);

    	if (!is_null($soldado)) {
    		$data = $request->getContent();

    		$data = json_decode($data);

            //$id = $data->equipo_id->input('id');

            echo $data->equipo_id;

            echo "\n";

            $equipo = equipo::find($data->equipo_id);

            //var_dump($equipo);

            echo "\n";


    		$soldado->equipo_id = (isset($data->equipo_id) ? $data->equipo_id : $soldado->equipo_id);

    		try{
	    		$soldado->save();
	    		$respuesta = "El soldado " .$soldado->nombre. " se ha asignado correctamente al equipo". " " . $equipo->nombre;

	    	}catch(\Exception $e){

	    		$respuesta = $e->getMessage();

	    	}
    	}else{

    		$respuesta = "El equipo no existe";
    	}

    	return response($respuesta);
    	
    }

        public function asignarCapitan(Request $request, $placa){
        $respuesta = "";

        $soldado = soldado::find($placa);

        //var_dump($soldado);

        if (!is_null($soldado)) {
            $data = $request->getContent();

            $data = json_decode($data);

            echo $data->capitan_id;

            echo "\n";

            $equipo = equipo::find($data->capitan_id);
            
            echo "$equipo";

            if (isset($data->capitan_id)) {
                $soldado->capitan_id = $data->capitan_id;
                $equipo->soldado_id = $data->capitan_id;  
                
                if (is_null($soldado->equipo_id)) {
                    $soldado->equipo_id = $data->capitan_id;
                }
                    
            }else{
                $soldado->capitan_id = $soldado->capitan_id;
                $soldado->equipo_id = $soldado->capitan_id;
            }

            try{
                $equipo->save();
                $soldado->save();
                $respuesta = "El soldado " .$soldado->nombre. " ha sido asignado como capitán del equipo". " " . $equipo->nombre;

            }catch(\Exception $e){

                $respuesta = $e->getMessage();

            }
        }else{

            $respuesta = "El equipo no existe";
        }

        return response($respuesta);
        
    }
}
