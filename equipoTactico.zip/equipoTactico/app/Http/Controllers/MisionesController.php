<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\mision;
use App\Models\equipo;
use App\Models\soldado;
use App\Models\registro;


class MisionesController extends Controller
{
	public function crearMision(Request $request){

    	$respuesta = "";

    	$data = $request->getContent();

    	$data = json_decode($data);

    	//var_dump($data);

    	$mision = new mision();

    	$mision->codigo = $data->codigo;
    	$mision->descripcion = $data->descripcion;
    	$mision->prioridad = $data->prioridad;
    	$mision->fecha_registro = $data->fecha_registro;

    	try{
    		$mision->save();
    		$respuesta = "Mision guardada en la base de datos";
    	}catch(\Exception $e){
    		$respuesta = $e->getMessage();
    	}


    	return response($respuesta);
    }

     public function modificarMision(Request $request, $codigo){
    	$respuesta = "";

    	$mision = mision::find($codigo);

    	//var_dump($mision);

    	//echo $mision;

    	if (!is_null($mision)) {

    		$data = $request->getContent();

    		$data = json_decode($data);

    		//var_dump($sold);


    		if (isset($data)) {
                $mision->descripcion = $data->descripcion;
                $mision->prioridad = $data->prioridad;
                $mision->estado = $data->estado;
            }

    		//var_dump($mision->estado);

    		try{
	    		$mision->save();
	    		$respuesta = "La misión se ha modificado correctamente";
	    	}catch(\Exception $e){
	    		$respuesta = $e->getMessage();
	    	}

    	}else{
    		$respuesta = "No existe esa mision";
    	}

    	return response($respuesta);

    }

    public function listaMisiones(Request $request){
        //$misiones = mision::all();

        $misiones = mision::orderBy('prioridad')->get();

        foreach($misiones as $mision) {

        	//echo $mision;


            //var_dump($mision);

            echo $mision->codigo ." ". $mision->fecha_registro ." ". $mision->prioridad ." ". $mision->estado;

        	echo "\n";
        }

        

        //echo $mision;
    }

    public function asignarEquipo(Request $request, $id){
        $respuesta = "";

        $equipo = equipo::find($id);

        //echo $equipo;
        //var_dump($equipo);

        if (!is_null($equipo)) {
            $data = $request->getContent();

            $data = json_decode($data);

            echo $data->codigo;

            echo "\n";

            $mision = mision::find($data->codigo);
            
            echo "\n";

            if (isset($data->codigo)) {
                $mision->codigo_id = $equipo->equipo_codigo;
                $mision->estado = 'en_curso';
			}

            try{
                $mision->save();
                $respuesta = "La mision " .$mision->codigo. " ha sido asignada al equipo". " " . $equipo->nombre;

            }catch(\Exception $e){

                $respuesta = $e->getMessage();

            }
        }else{

            $respuesta = "La mision no existe o el equipo";
        }

        return response($respuesta);
        
    }

    public function asignarSoldado(Request $request, $placa){
        $respuesta = "";

        $soldado = soldado::find($placa);
        //$equipo = equipo::find($soldado->codigo_id);

        //echo $equipo->nombre;
        //var_dump($soldado);

        if (!is_null($soldado)) {
            $data = $request->getContent();

            $data = json_decode($data);

            //echo $soldado;

            echo "\n";

            $mision = mision::find($data->codigo);

            //echo $mision;

            if ($soldado->equipo_id == $mision->codigo_id) {

                $registrar = new registro();

                $registrar->codigo = $mision->codigo;
                $registrar->descripcion = $mision->descripcion;
                $registrar->prioridad = $mision->prioridad;
                $registrar->fecha_registro = $mision->fecha_registro;
                $registrar->estado = $mision->estado;
                $registrar->soldado_placa = $soldado->placa;
                $registrar->codigo_id = $mision->codigo_id;

                $respuesta = "Soldado " . $soldado->nombre . " registrado";

                try{
                    $registrar->save();
                    
                }catch(\Exception $e){

                    $respuesta = $e->getMessage();

                }

            }else{
                $respuesta = "Este soldado no pertenece al equipo";
            }


        }else{

            $respuesta = "La mision no existe o el soldado";
        }

        return response($respuesta);
        
    }
}
