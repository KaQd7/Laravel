<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\soldado;
use App\Models\equipo;

use DB;

class SoldadosController extends Controller
{
    
    public function crearSoldado(Request $request){

    	$respuesta = "";

    	$data = $request->getContent();
        
    	$data = json_decode($data);

    	var_dump($data->nombre);

    	$soldado = new soldado();

    	$soldado->nombre = $data->nombre;
    	$soldado->apellidos = $data->apellidos;
    	$soldado->fecha_nacimiento = $data->fecha_nacimiento;
    	$soldado->fecha_incorporacion = $data->fecha_incorporacion;
    	$soldado->placa = $data->placa;
    	$soldado->rango = $data->rango;
    	$soldado->estado = $data->estado;

    	try{
    		$soldado->save();
    		$respuesta = "Soldado guardado en la base de datos";
    	}catch(\Exception $e){
    		$respuesta = $e->getMessage();
    	}


    	return response($respuesta);
    }

    public function estadoSoldado(Request $request, $placa){
    	$respuesta = "";

    	$soldado = soldado::find($placa);

    	//var_dump($soldado);

    	//echo $soldado;

    	if (!is_null($soldado)) {

    		$data = $request->getContent();

    		$data = json_decode($data);

    		//var_dump($sold);


    		$soldado->estado = (isset($data->estado) ? $data->estado : $soldado->estado);

    		var_dump($soldado->estado);

    		try{
	    		$soldado->save();
	    		$respuesta = "Soldado guardado en la base de datos";
	    	}catch(\Exception $e){
	    		$respuesta = $e->getMessage();
	    	}

    	}else{
    		$respuesta = "No existe ese soldado";
    	}

    	return response($respuesta);

    }

    public function listaTodos(Request $request){
        $soldados = soldado::all();

        foreach($soldados as $soldado) {

            $equipo = equipo::find($soldado->equipo_id);

            $equipo = json_decode($equipo);

            //var_dump($equipo);

            if (isset($equipo->nombre)) {
                echo $soldado->nombre ." ". $soldado->apellidos ." ". $soldado->rango ." ". $soldado->placa ." ". $soldado->equipo_id ." ". $equipo->nombre;
            }else{

                echo $soldado->nombre ." ". $soldado->apellidos ." ". $soldado->rango ." ". $soldado->placa ." ". $soldado->equipo_id;
            }
            echo "\n";
        }
    }

    public function infoSoldado(Request $request, $placa){
        $soldado = soldado::find($placa);

        $equipo_id = equipo::find($soldado->equipo_id);

        //$capitanInfo = soldado::where('capitan_id', '=', $equipo_id->soldado_id)->get();



        //var_dump($capitanInfo);

        $todos = soldado::all();

        foreach($todos as $uno) {



            if (!is_null($uno->capitan_id)) {
                
                if ($soldado->equipo_id == $uno->capitan_id) {
                    
                    echo $soldado->nombre ." ". $soldado->apellidos ." ". $soldado->fecha_nacimiento ." ". $soldado->fecha_incorporacion ." ". $soldado->rango ." ". $soldado->placa ." ". $soldado->estado ." ". $soldado->equipo_id ." ". $equipo_id->nombre;

                    echo "Su capitán es: " . $uno->nombre ." ". $uno->placa ." ". $uno->rango ." ". $uno->apellidos;
                }


            }else{

                echo "No hay ningún capitan o el soldado no tiene capitan";
            }

            echo "\n";

            die;
        }

    }
}
