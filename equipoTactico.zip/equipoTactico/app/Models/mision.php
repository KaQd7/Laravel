<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class mision extends Model
{
    use HasFactory;

    protected $table = 'misiones';
    public $incrementing = false;
    protected $primaryKey = 'codigo';
    protected $keyType = 'string';

    public function mision_equipo(){

        return $this->hasOne(mision::class, 'equipo_codigo', 'codigo_id');
    }

    public function soldados_equipo(){

        return $this->hasMany(soldado::class, 'placa', 'codigo_id');
    }

}
