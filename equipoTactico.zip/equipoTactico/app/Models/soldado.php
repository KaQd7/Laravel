<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class soldado extends Model
{
    use HasFactory;

    protected $table = 'soldados';
    public $incrementing = false;
    protected $primaryKey = 'placa';
    protected $dateFormat = 'Y-m-d';

    public function capitan_equipo(){

        return $this->belongsTo(equipo::class, 'soldado_id', 'capitan_id');
    }

    public function soldado_mision(){

        return $this->belongsTo(mision::class, 'codigo_id', 'placa');
    }
}
