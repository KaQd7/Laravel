<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class equipo extends Model
{
    use HasFactory;

    protected $table = 'equipos';

    /*public function soldados(){

    	return $this->hasMany(soldado::class);

    }*/

    public function soldados_equipo(){

        return $this->hasOne(soldado::class,'soldado_id', 'capitan_id');
    }

    public function capitan_equipo(){

        return $this->belongsTo(mision::class,'codigo_id', 'equipo_codigo');
    }
}
